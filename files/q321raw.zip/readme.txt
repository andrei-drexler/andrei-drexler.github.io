
  .g8""8q.                           
.dP'    `YM.                    __,  
dM'      `MM  pd""b.   pd*"*b. `7MM  
MM        MM (O)  `8b (O)   j8   MM  
MM.      ,MP      ,89     ,;j9   MM  
`Mb.    ,dP'    ""Yb.  ,-='      MM  
  `"bmmd"'         88 Ammmmmmm .JMML.
      MMb    (O)  .M'                
       `bood' bmmmd'                 

An unofficial Quake III: Arena demake in 63,420 bytes*
Also, a work in progress.
Andrei Drexler, 2 Dec 2020 


// REQUIREMENTS //

- Windows
- OpenGL 3.3 compatible GPU & drivers
- 1 GB RAM
- mouse and keyboard
- nostalgia


// CONTROLS //

WASD, up/down = move
left/right    = turn left/right
Del/PageDown  = look down/up
End           = center view
Space         = jump
Backspace     = respawn
Backslash     = toggle noclip
L             = toggle lightmap


// WAIT, IS THIS A VIRUS? //

It is not. However, it *is* a packed executable, which will likely get flagged by some overzealous
antivirus programs. For what it's worth, this is one reason why the file is compressed with
Crinkler (meant for 4k intros), and not a more suitable 64k packer (e.g. squishy):
Microsoft Security Essentials/Windows Defender doesn't seem to flag Crinkler-generated EXEs.


// ROADMAP //

[ this section intentionally left blank ]



// CREDITS //

This is an *unofficial* recreation of Quake III: Arena (1999).
QUAKE, id, id Software and related logos are registered trademarks or trademarks
of id Software LLC in the U.S. and/or other countries.

Many thanks to:

- id Software for the original Quake III game, map samples, data specifications and code
  https://www.idsoftware.com/
  https://github.com/id-Software/
  
- Aske Simon Christensen "Blueberry/Loonies" and Rune L. H. Stubbe "Mentor/TBC"
  for the amazing Crinkler (Compressing linker for Windows specialized for 4k intros)
  http://crinkler.net/

- Inigo Quilez for articles and code covering noise, signed distance fields, and more
  https://www.iquilezles.org/

- ShaderToy user Dave_Hoskins for the "Hash without Sine" functions
  https://www.shadertoy.com/view/4djSRW

- ShaderToy user Shane for the 'Asymmetric Blocks' function
  https://www.shadertoy.com/view/Ws3GRs

- Dr Martin Roberts for the R2 sequence
  http://extremelearning.com.au/unreasonable-effectiveness-of-quasirandom-sequences/

---
* For now. Might balloon up later.
